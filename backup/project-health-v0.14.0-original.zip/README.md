# Project Health v0.14.0 — Mobile Coach + Meal Planner

Upload every file and folder in this release to the root of the GitHub `Project-Health` repository, replacing existing files.

## Major improvements
- Five-section mobile navigation: Home, Fitness, Nutrition, Progress, Coach PH
- App-style mobile layout and persistent Settings access
- Live estimated calories during active cardio/mobility sessions
- Coach PH meal requests such as: “Today make fish with rice and vegetables”
- Recipes with estimated nutrition, ingredients, directions, servings, grocery lists, and one-tap meal logging
- Existing Supabase cloud configuration and stable sync preserved

## Important calorie note
Calories shown during activities are estimates based on activity type, elapsed time, and the user's latest saved weight. Measured real-time calories require future wearable or health-platform integration.

## Deploy
1. Extract the ZIP.
2. Upload all contents to the root of the GitHub repository.
3. Replace existing files when prompted.
4. Wait for GitHub Pages deployment.
5. On mobile, close and reopen the installed app. If an old build remains, clear the site cache once.

Your existing cloud account and data remain compatible.
